package com.example.codingcafe.chatter;

public class groups {
    public groups(){}

    public String grouppname;
    public groups(String grouppname){

        this.grouppname=grouppname;
    }

    public String getGrouppname() {
        return grouppname;
    }

    public void setGrouppname(String grouppname) {
        this.grouppname = grouppname;
    }
}
