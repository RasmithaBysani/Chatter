package com.example.codingcafe.chatter;

public class store {

    public static  String mobileno = null;
    public static  String cgroupname = null;


}
